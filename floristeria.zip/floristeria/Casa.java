package floristeria;

public class Casa {
	//Atributos de Clase
	private String color;
	private int numHabitaciones;
	private int numBanos;
	private boolean tienePatio;
	private boolean tieneParqueadero;
	
	/**
	 * Constructor de la clase casa
	 * @param color color de la casa
	 * @param numHabitaciones números de habitaciones de la casa
	 * @param numBanos número de baños de la casa
	 * @param tienePatio coloque true o false dependiendo si hay o no patio
	 * @param tieneParqueadero coloque true o false dependiendo si hay o no parqueadero
	 */
	
	public Casa(String color,int numHabitaciones,int numBanos,boolean tienePatio,boolean tieneParqueadero) {
		this.color=color;
		this.numHabitaciones=numHabitaciones;
		this.numBanos=numBanos;
		this.tienePatio=tienePatio;
		this.tieneParqueadero=tieneParqueadero;
		
	}
	
	public String describir() {
		/**
		 * Metodó para describir la casa
		 */
		String descripción="La casa es de color " + this.color + ". Tiene " + this.numHabitaciones + " habitación(es) y " 
		 + this.numBanos + " baño(s).";
	
		if (tienePatio) {descripción+="\nTiene Patio.";}
		if (tieneParqueadero) {descripción+="\nTiene Parquedero.";}
		return descripción;
	}
	
	public void pintar(String nuevoColor) {
		this.color=nuevoColor;
		System.out.println("La casa ha sido de pintada de color " + this.color);
	}
}
