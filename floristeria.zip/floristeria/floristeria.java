package floristeria;

public class floristeria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa santiagoCasa=new Casa("Blanca",6,7,true,true);
		System.out.println(santiagoCasa.describir());
		santiagoCasa.pintar("Le agrego el T1.");
		System.out.println(santiagoCasa.describir());
	}

}
