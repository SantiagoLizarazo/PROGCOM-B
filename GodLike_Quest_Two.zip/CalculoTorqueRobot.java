import java.util.Scanner;

class Main {

    // Constante de la gravedad
    private static final double G = 9.81; // m/s^2

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // --- Propiedades del Brazo Robótico ---
        double masaEslabon1 = 2.0; // kg
        double longitudEslabon1 = 0.5; // metros

        double masaEslabon2 = 1.0; // kg
        double longitudEslabon2 = 0.4; // metros

        // --- Entrada de la Carga ---
        System.out.print("Ingrese la masa de la carga en kilogramos (kg): ");
        double masaCarga = scanner.nextDouble();
        scanner.close();

        // --- Cálculo de Fuerzas ---
        double fuerzaEslabon1 = masaEslabon1 * G;
        double fuerzaEslabon2 = masaEslabon2 * G;
        double fuerzaCarga = masaCarga * G;

        // --- Cálculo de Torques ---
        
        // Torque en la Articulación 2 (Codo)
        // El torque en esta articulación solo considera el peso del eslabón 2 y la carga.
        double torqueArticulacion2 = (fuerzaEslabon2 * (longitudEslabon2 / 2)) + (fuerzaCarga * longitudEslabon2);
        
        // Torque en la Articulación 1 (Base)
        // El torque en la base considera el peso de ambos eslabones y la carga.
        double torqueArticulacion1 = (fuerzaEslabon1 * (longitudEslabon1 / 2)) + 
                                     (fuerzaEslabon2 * (longitudEslabon1 + (longitudEslabon2 / 2))) +
                                     (fuerzaCarga * (longitudEslabon1 + longitudEslabon2));

        // --- Impresión de Resultados ---
        System.out.println("\n--- Cálculo de Torques Requeridos ---");
        System.out.println("Carga a levantar: " + masaCarga + " kg");
        System.out.printf("Torque requerido en la articulación 2 (codo): %.2f Nm%n", torqueArticulacion2);
        System.out.printf("Torque requerido en la articulación 1 (base): %.2f Nm%n", torqueArticulacion1);
        
        System.out.println("\nNOTA: Estos cálculos asumen que el brazo está completamente extendido de forma horizontal.");
    }
}