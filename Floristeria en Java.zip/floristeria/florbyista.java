package floristeria;

public class florbyista extends Casa {

    private String colorFachada;
    private String colorLateral;
    private String colorPuerta;
    private String materialTecho;
    private String logo;

    private int totalFloresInterior;
    private int totalFloresExterior;

    // Detalles de la puerta
    private double anchoPuerta;
    private double altoPuerta;
    private String materialPuerta;

    /**
     * Constructor de la Floristeria.
     * Rellena los valores basándose en la descripción de la imagen.
     */
    public florbyista() {
        super("Amarillo", 1, 1, true, false);

        // Inicializamos los atributos propios de la Floristeria
        this.colorFachada = "Amarillo";
        this.colorLateral = "Azul";
        this.colorPuerta = "Rosado";
        this.materialTecho = "Tejas de barro artesanales";
        this.logo = "Logo 'Flor by Ista' en letras cursivas con un racimo de 3 flores y dos hojas";

        // Resumen de flores
        this.totalFloresInterior = 14; // (Lirios, Orquídeas y Rosas)
        this.totalFloresExterior = 9;  // (Girasoles)

        // Detalles de la puerta
        this.anchoPuerta = 72.5;
        this.altoPuerta = 203.0;
        this.materialPuerta = "Madera de roble con herrajes de hierro forjado";
    }

    /**
     * Sobrescribimos (Override) el método describir() de la clase Casa
     * para mostrar la descripción específica de la Floristería.
     */
    @Override
    public String describir() {

        String desc = "--- Descripción Arquitectónica de la Floristería Flor by Ista ---\n\n";
        desc += "Estructura Base: 4 paredes de ladrillo rojo y cemento fino con diseño de seguridad.\n";
        desc += "Techo: De tamaño grande con " + this.materialTecho + ".\n\n";

        desc += "--- Fachadas y Colores ---\n";
        desc += "* Fachada Principal: Color " + this.colorFachada + ".\n";
        desc += "* Fachada Posterior: Color " + this.colorFachada + ".\n";
        desc += "* Laterales (Izquierda y Derecha): Color " + this.colorLateral + ".\n\n";

        desc += "--- Puertas y Ventanas ---\n";
        desc += "* Puerta Principal: Color " + this.colorPuerta + ", de " + this.materialPuerta +
                " (" + this.anchoPuerta + " cm x " + this.altoPuerta + " cm).\n";
        desc += "* Ventana Izquierda: Translúcida, con el logo: \"" + this.logo + "\".\n";
        desc += "* Ventana Posterior: Tipo tragaluz.\n";
        desc += "* Ventana Derecha: Translúcida, permite ver plantas colgantes.\n\n";

        desc += "--- Resumen de Flores en Exhibición ---\n";
        desc += "* Flores Interiores (Total " + this.totalFloresInterior + "): 14 unidades (Lirios, Orquídeas y Rosas).\n";
        desc += "* Flores Exteriores (Total " + this.totalFloresExterior + "): 9 girasoles (en matera posterior).\n";

        return desc;
    }

    /**
     * Sobrescribimos el método 'pintar' de la Casa.
     * Ahora, 'pintar' se refiere a la fachada principal.
     */
    @Override
    public void pintar(String nuevoColor) {
        //Llama al método original de Casa para cambiar el color
        super.pintar(nuevoColor);
        this.colorFachada = nuevoColor;
        System.out.println("La FACHADA PRINCIPAL de la floristería ha sido pintada de color " + nuevoColor);
    }

    /**
     * Nuevo método que solo existe en Floristeria.
     */
    public void pintarLaterales(String nuevoColor) {
        this.colorLateral = nuevoColor;
        System.out.println("Las fachadas LATERALES han sido pintadas de color " + nuevoColor);
    }

    /**
     * Nuevo método que solo existe en Floristeria.
     */
    public void pintarPuerta(String nuevoColor) {
        this.colorPuerta = nuevoColor;
        System.out.println("La PUERTA ha sido pintada de color " + nuevoColor);
    }

    public String getColorLateral() {
        return colorLateral;
    }

    public String getColorPuerta() {
        return colorPuerta;
    }
}