package floristeria;

public class floristeria {
    public static void main(String[] args) {

        // Creamos una instancia de nuestra nueva clase
        florbyista miTienda = new florbyista();

        // Usamos el método sobrescrito describir()
        // Esto mostrará la descripción general de la floristería
        System.out.println(miTienda.describir());

        System.out.println("======================================================");
        System.out.println("                     PINTANDO LA TIENDA...");
        System.out.println("======================================================");

        // Usamos el método 'pintar()'
        miTienda.pintar("Blanco Nube");

        // Usamos el nuevo método 'pintarLaterales()'
        miTienda.pintarLaterales("Azul Cielo");
    }
}